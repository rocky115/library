//var Person = function(config){
//  this.name = config.name;
//  this.age = config.age;
//  this.occupation = config.occupation;
//};
//
//Person.prototype.work = function(){
//	return this.name + 'is working.';
//};

var Person = Backbone.Model.extend({
	 defaults:{
		 name : 'rmd',
		 age :32,
		 occupation : 'worker'
		 },
		 work : function(){
			 return this.get('name')+ 'is working';
			 },
			 
			 validate : function(attributes){
				 if(attributes < 0){
					 return 'Age must be positive';
					 }
				 }
		 
	});  
	
	
	var PersonView = Backbone.View.extend({
		tagName : 'li',
		
		my_template : _.template($('#personTemplate').html()),
		
		initialize : function(){
			this.render();
			},
			
			render : function(){
				//this.$el.html("hello" + this.model.get('name')+" age :" + this.model.get('age'));
				
				this.$el.html(this.my_template(this.model.toJSON()));
				}
		
		});
		

var person = new Person;
var personView = new PersonView({ model: person });
personView.el;

// lets create a new person and display that person in view..
var person = new Person({name: "rmd", age: 32, occupation: "Computer Engineer"})
var personView = new PersonView({ model: person });
personView.el;
$(document.body).html(personView.el); 