<script id="personTemplate" type="text/template">
<strong><%= name %></strong> (<%= age %>)(<%= occupation %>)
</script>