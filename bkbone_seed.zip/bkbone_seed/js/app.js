var post = Backbone.Model.extend({});
var posts = Backbone.Collection.extend({
	 model : Post,
	 url : "/posts"
	});