angular.module('appMaps')
.controller('1056TemplateController', function ($scope, $log) {});
