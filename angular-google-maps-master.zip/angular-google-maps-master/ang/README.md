angulardemorestful
==================

Java REST service and AngularJs

This is a sample project for my blog post at [http://draptik.github.io/blog/2013/07/13/angularjs-example-using-a-java-restful-web-service/](http://draptik.github.io/blog/2013/07/13/angularjs-example-using-a-java-restful-web-service/)

